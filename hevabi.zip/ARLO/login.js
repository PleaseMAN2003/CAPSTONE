// Show Register Form
function showRegister() {
  document.getElementById("loginForm").classList.add("hidden");
  document.getElementById("registerForm").classList.remove("hidden");
}

// Show Login Form
function showLogin() {
  document.getElementById("registerForm").classList.add("hidden");
  document.getElementById("loginForm").classList.remove("hidden");
}

// Login Form Validation
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let email = document.getElementById("loginEmail").value;
  let password = document.getElementById("loginPassword").value;
  let message = document.getElementById("loginMessage");

  if(email === "" || password === "") {
    message.style.color = "red";
    message.textContent = "⚠ Please fill in all fields.";
  } else {
    message.style.color = "green";
    message.textContent = "✅ Logged in successfully! (demo only)";
  }
});

// Register Form Validation
document.getElementById("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let name = document.getElementById("regName").value;
  let batch = document.getElementById("regBatch").value;
  let email = document.getElementById("regEmail").value;
  let password = document.getElementById("regPassword").value;
  let message = document.getElementById("registerMessage");

  if(name === "" || batch === "" || email === "" || password === "") {
    message.style.color = "red";
    message.textContent = "⚠ Please complete all fields.";
  } else {
    message.style.color = "green";
    message.textContent = "✅ Registered successfully! (demo only)";
  }
});
