<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect all form data
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $suffix = $_POST['suffix'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $civilstatus = $_POST['civilstatus'];

    // (You can continue collecting other fields here)
    
    // Example: Display confirmation message
    echo "<h2>Form Submitted Successfully!</h2>";
    echo "<p>Name: $firstname $middlename $lastname</p>";
    echo "<p>Gender: $gender</p>";
    echo "<p>Status: $civilstatus</p>";

    // If you plan to save it to a database:
    // 1. Connect to your database (MySQL)
    // 2. Use INSERT query to save data
}
?>
