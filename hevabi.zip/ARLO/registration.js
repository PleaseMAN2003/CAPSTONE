const fieldsets = document.querySelectorAll("fieldset");
let currentStep = 0;

function showStep(step) {
  fieldsets.forEach((fs, index) => {
    fs.classList.toggle("active", index === step);
  });
}

showStep(currentStep);

// Validate inputs before going to the next step
function validateStep(step) {
  const inputs = fieldsets[step].querySelectorAll("input, select, textarea");
  for (let input of inputs) {
    if (input.hasAttribute("required") && !input.value.trim()) {
      alert("Please fill out all required fields before proceeding.");
      input.focus();
      return false;
    }
  }
  return true;
}

// Next button
document.querySelectorAll(".next-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    if (!validateStep(currentStep)) return; // Stop if invalid
    if (currentStep < fieldsets.length - 1) {
      currentStep++;
      showStep(currentStep);
      window.scrollTo(0, 0);
    }
  });
});

// Previous button
document.querySelectorAll(".previous-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    if (currentStep > 0) {
      currentStep--;
      showStep(currentStep);
      window.scrollTo(0, 0);
    }
  });
});


// ==================== DROPDOWN POPULATION ====================

// Populate Year Graduated (1914 to Present)
const yearSelect = document.getElementById("yearGraduated");
if (yearSelect) {
  const currentYear = new Date().getFullYear();
  for (let year = currentYear; year >= 1914; year--) {
    let option = document.createElement("option");
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
  }
}

// Populate Departments
const departments = [
  "College of Agriculture",
  "College of Arts and Sciences",
  "College of Education",
  "College of Veterinary Medicine",
  "College of Engineering",
  "College of Forestry and Environmental Science",
  "College of Business and Management",
  "College of Human Ecology",
  "College of Nursing",
  "College of Information Sciences and Computing",
];

const deptSelect = document.getElementById("department");
if (deptSelect) {
  departments.forEach((dept) => {
    let option = document.createElement("option");
    option.value = dept;
    option.textContent = dept;
    deptSelect.appendChild(option);
  });
}

// Populate Region of Origin
const regionofOrigin = [
  "NCR – National Capital Region",
  "CAR – Cordillera Administrative Region",
  "Region I – Ilocos Region",
  "Region II – Cagayan Valley",
  "Region III – Central Luzon",
  "Region IV-A – CALABARZON",
  "Region IV-B – MIMAROPA",
  "Region V – Bicol Region",
  "Region VI – Western Visayas",
  "Region VII – Central Visayas",
  "Region VIII – Eastern Visayas",
  "Region IX – Zamboanga Peninsula",
  "Region X – Northern Mindanao",
  "Region XI – Davao Region",
  "Region XII – SOCCSKSARGEN",
  "Region XIII – Caraga",
  "BARMM – Bangsamoro Autonomous Region in Muslim Mindanao",
  "N/A",
];

const regSelect = document.getElementById("regionofOrigin");
if (regSelect) {
  regionofOrigin.forEach((reg) => {
    let option = document.createElement("option");
    option.value = reg;
    option.textContent = reg;
    regSelect.appendChild(option);
  });
}

// Populate Country
const country = ["Philippines", "Other"];
const countrySelect = document.getElementById("country");
if (countrySelect) {
  country.forEach((country) => {
    let option = document.createElement("option");
    option.value = country;
    option.textContent = country;
    countrySelect.appendChild(option);
  });
}

// Populate Highschool
const highschool = [
  "CMULHS - Junior Highschool Graduated",
  "CMULHS - Senior Highschool Graduated",
  "CMU Laboratory High School",
  "CMU - Senior High School",
  "N/A",
];

const highschoolSelect = document.getElementById("highschool");
if (highschoolSelect) {
  highschool.forEach((school) => {
    let option = document.createElement("option");
    option.value = school;
    option.textContent = school;
    highschoolSelect.appendChild(option);
  });
}

// Populate Degree
const degree = [
  "Bachelor of Science in Agriculture",
  "Bachelor of Science in Development Communication",
  "Bachelor of Arts in English",
  "Bachelor of Arts in History",
  "Bachelor of Arts in Political Science",
  "Bachelor of Arts in Psychology",
  "Bachelor of Arts in Sociology",
  "Bachelor of Science in Biology",
  "Bachelor of Science in Chemistry",
  "Bachelor of Science in Mathematics",
  "Bachelor of Science in Forestry",
  "Bachelor of Science in Environmental Science",
  "Bachelor of Science in Business Administration",
  "Bachelor of Science in Accountancy",
  "Bachelor of Science in Accounting Technology",
  "Bachelor of Science in Office Administration",
  "Bachelor of Science in Education",
  "Bachelor of Science in Home Economics Education",
  "Bachelor of Science in Food Technology",
  "Bachelor of Science in Hotel and Restaurant Management",
  "Bachelor of Science in Nutrition and Dietetics",
  "Bachelor of Science in Nursing",
];

const degreeSelect = document.getElementById("degree");
if (degreeSelect) {
  degree.forEach((deg) => {
    let option = document.createElement("option");
    option.value = deg;
    option.textContent = deg;
    degreeSelect.appendChild(option);
  });
}

// Populate Major
const major = [
  "Major in Agronomy",
  "Major in Agricultural Economics",
  "Major in Agricultural Education",
  "Major in Agricultural Extension",
  "Major in Animal Science",
  "Major in Entomology",
  "Major in Horticulture",
  "Major in Plant Pathology",
  "Major in Soil Science",
  "Major in Marketing Management",
  "Major in Operations Management",
  "Major in Financial Management",
  "Major in Biology",
  "Major in English",
  "Major in Filipino",
  "Major in General Science",
  "Major in Mathematics",
  "Major in Physical Education",
  "Major in History",
  "Major in Political Science",
  "Major in Psychology",
  "Major in Sociology",
  "Major in Software Development",
  "Major in Information Management",
  "Major in Data Networking",
  "N/A",
];

const majorSelect = document.getElementById("major");
if (majorSelect) {
  major.forEach((mj) => {
    let option = document.createElement("option");
    option.value = mj;
    option.textContent = mj;
    majorSelect.appendChild(option);
  });
}
